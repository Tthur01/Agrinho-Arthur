// Coordenadas dos pontos do mapa
let xEscola = 148
let yEscola = 116

let xFabrica = 482
let yFabrica = 142

let xIgreja = 142
let yIgreja = 424

let xPraça = 463
let yPraça = 418

let mapa;

function preload(){
  mapa = loadImage("Mapa 1.jpg"); 
}

function setup() {
  createCanvas(600, 500);
}

function draw(){
  background(255);
  image(mapa, 0, 0, width, height);
  
  fill(0)
  text("x: " + mouseX + "Y: " + mouseY, 10,20)
  
  // escola ine
  fill("red")
  ellipse(148, 116, 15, 15)
  
  // Santa Clara
    fill("red")
  ellipse(482, 147, 15, 15)
  
  
    // Igreja Bom Jardim
    fill("red")
  ellipse(142, 424, 15, 15)
  
  
    // Praça Bom Jardim
    fill("red")
  ellipse(463, 418, 15, 15)
}

function draw() {
  background(220)
image(mapa, 0, 0, width, height)
  
  stroke(0)
  strokeWeight(2)
  
  line(xEscola, yEscola, xIgreja, yIgreja)
  
  line(xEscola, yEscola, xFabrica, yFabrica)
  
  line(xIgreja, yIgreja, xFabrica, yFabrica)
  
  if (dist(mouseX, mouseY, (xEscola + xFabrica)/2, (yEscola + yFabrica)/2) < 20) {
    fill(0)
    text("A escola leva seus alunos para conhecer a fabrica e saber como funciona a fabricação de papel", (xEscola + xFabrica)/2, (yEscola + yFabrica)/2) 
  }
  /
  }



}